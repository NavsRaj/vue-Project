<template>
  <v-app>
    <v-card flat>
      <v-card-title class="d-flex justify-center mb-0">
        <v-icon color="black">mdi-account-box</v-icon>
        - Welcome To Login Page
      </v-card-title>
    </v-card>
    <v-col class="mt-0">
      <v-card flat class="d-flex align-center justify-center mt-0">
        <v-sheet>
          <v-alert
            :value="alert"
            v-model="alert"
            dismissible
            color="red"
            border="left"
            elevation="2"
            colored-border
            icon="mdi-information"
            >sign-in failed!</v-alert
          >
          <v-alert
            :value="alert"
            v-model="alertsuccess"
            dismissible
            color="green"
            border="left"
            elevation="2"
            colored-border
            icon="mdi-information"
            >sign-in successfully!</v-alert
          >
          <v-text-field
            v-model="email"
            :error-messages="emailErrors"
            label="E-mail"
            required
            outlined
            @input="$v.email.$touch()"
            @blur="$v.email.$touch()"
            append-icon="mdi-email"
          ></v-text-field>
          <v-text-field
            v-model="password"
            :error-messages="passwordErrors"
            label="password"
            type="password"
            required
            outlined
            @input="$v.password.$touch()"
            @blur="$v.password.$touch()"
            append-icon="mdi-lock"
          ></v-text-field>
          <v-row class="mt-4">
            <v-btn class="green mx-5" @click="login">
              <v-icon>mdi-login</v-icon>sign-in
            </v-btn>
            <v-btn class="yellow mx-2" @click="resetFields"
              ><v-icon>mdi-restore</v-icon> reset
            </v-btn>
          </v-row>
        </v-sheet>
      </v-card>
    </v-col>
  </v-app>
</template>
<script>
import { validationMixin } from 'vuelidate'
import { required, maxLength, email } from 'vuelidate/lib/validators'
export default {
  name: 'loginComponent',
  mixins: [validationMixin],
  validations: {
    email: { required, email },
    password: { required, maxLength: maxLength(8) },
  },
  data() {
    return {
      email: '',
      password: '',
      alert: false,
      alertsuccess: false,
    }
  },
  computed: {
    emailErrors() {
      const errors = []
      if (!this.$v.email.$dirty) return errors
      !this.$v.email.email && errors.push('Must be valid e-mail')
      !this.$v.email.required && errors.push('E-mail is Required')
      return errors
    },
    passwordErrors() {
      const errors = []
      if (!this.$v.password.$dirty) return errors
      !this.$v.password.maxLength &&
        errors.push('Password must be at most 8 characters long')
      !this.$v.password.required && errors.push('Password is Required.')
      return errors
    },
  },
  methods: {
    resetFields() {
      this.$v.$reset()
      this.email = ''
      this.password = ''
    },
    async login() {
      this.$v.$touch()
      if (this.email !== '' && this.password !== '') {
        try {
          const response = await this.$axios.get(process.env.url, {
            params: {
              email: this.email,
              password: this.password,
            },
          })
           const users = response.data
          console.log(users)
          if (users.length === 1) {
            this.alertsuccess = true
            setTimeout(() => {
             this.$router.push('/dashBoard')
            }, 1000)
            this.$store.commit('setUsers', users[0])
          } else {
            this.alert = true
            setTimeout(() => {
              this.alert = false
            }, 1000)
          }
        } 
        catch (error) {
          console.error('login failed', error)
          alert('login failed. please try again later.')
        }
      }
    },
  },
}
</script>
<style scoped></style>
