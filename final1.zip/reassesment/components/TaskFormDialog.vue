<template>
  <div>
    <v-app>
      <v-dialog
        v-model="dialog"
        persistent
        max-width="600"
        max-height="500"
      >
        <v-card>
          <v-card-title class="parent">
            <div>
              <h1 class="text-uppercase">Add Task {{ currentuserId }}</h1>
            </div>
            <div>
              <v-btn @click="closePopUp" class="red">
                <v-icon class="white--text"> mdi-close </v-icon>
              </v-btn>
            </div>
          </v-card-title>
          <v-card-text>
            <v-text-field
              label="Task"
              v-model="task"
              :error-messages="taskErrors"
              @input="$v.task.$touch()"
              @blur="$v.task.$touch()"
              outlined
            ></v-text-field>
            <v-text-field
              label="Description"
              v-model="taskDescription"
              :error-messages="taskDescriptionErrors"
              @input="$v.taskDescription.$touch()"
              outlined
            ></v-text-field>
            <v-select
              label="Priority"
              v-model="priority"
              :items="priorityOptions"
              :error-messages="priorityErrors"
              outlined
            ></v-select>
            <template>
              <v-menu
                ref="menu"
                v-model="menu"
                :close-on-content-click="false"
                :return-value.sync="date"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="date"
                    label="Deadline"
                    append-icon="mdi-calendar"
                    outlined
                    v-bind="attrs"
                    v-on="on"
                  ></v-text-field>
                </template>
                <v-date-picker v-model="date" no-title scrollable>
                  <v-spacer></v-spacer>
                  <v-btn text color="primary" @click="menu = false">
                    Cancel
                  </v-btn>
                  <v-btn text color="primary" @click="$refs.menu.save(date)">
                    OK
                  </v-btn>
                </v-date-picker>
              </v-menu>
            </template>
            <v-radio-group v-model="selectedStatus">
              <v-subheader class="black--text text-uppercase">
                task-Status</v-subheader
              >
              <v-radio label="pending" value="pending"></v-radio>
              <v-radio label="completed" value="completed"></v-radio>
            </v-radio-group>
          </v-card-text>
          <v-card-actions>
            <v-spacer></v-spacer>
            <v-dialog
              max-width="600px"
              max-height="500px"
              v-model="usersDialog"
              persistent
            >
              <v-card>
                <v-card-title class="parent">
                  <div>
                    <h1 class="text-uppercase">
                      <v-icon> mdi-task</v-icon>Assigning Task
                      {{ selectedUser }}
                    </h1>
                  </div>
                  <div>
                    <v-btn class="red" @click="closeInnerPopup">
                      <v-icon class="white--text"> mdi-close </v-icon>
                    </v-btn>
                  </div>
                </v-card-title>
                <v-card-text>
                  <v-select
                    label="Select User"
                    v-model="selectedUser"
                    :items="users"
                    item-text="name"
                    item-value="id"
                  >
                  </v-select>
                </v-card-text>
                <v-card-actions>
                  <v-btn class="green white--text" @click="save">
                    <v-icon class="black large"> mdi-save-content</v-icon>
                    save
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
            <v-btn
              class="blue text-uppercase"
              dark
              @click="openAddUserDialog"
              :disabled="!isFormValid">
              <v-icon> mdi-plus </v-icon>
              <!-- {{ buttonToggle === 0 ? 'add-users' : 'updateUsers' }} -->
              add user
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-app>
  </div>
</template>
<script>
import axios from 'axios'
import { validationMixin } from 'vuelidate'
import { required, maxLength } from 'vuelidate/lib/validators'
export default {
  mixins: [validationMixin],
  validations: {
    task: {
      required,
      maxLength: maxLength(20),
    },
    taskDescription: {
      required,
      maxLength: maxLength(40),
    },
    priority: {
      required,
    },
  },
  computed: {
    taskErrors() {
      const errors = []
      if (!this.$v.task.$dirty) return errors
      !this.$v.task.required && errors.push('Task is required')
      return errors
    },
    taskDescriptionErrors() {
      const errors = []
      if (!this.$v.taskDescription.$dirty) return errors
      !this.$v.taskDescription.required &&
        errors.push('Description is required')
      return errors
    },
    priorityErrors() {
      const errors = []
      if (!this.$v.priority.$dirty) return errors
      !this.$v.priority.required && errors.push('Priority is required')
      return errors
    },
    isFormValid() {
      return (
        this.task.trim() !== '' &&
        this.taskDescription.trim() !== '' &&
        this.priority !== '' &&
        this.date !== '' &&
        this.selectedStatus !== '' &&
        this.priorityOptions !== ''
      )
    },
  },
  data() {
    return {
      task: '',
      dialog: false,
      taskDescription: '',
      priority: '',
      date: '',
      selectedStatus: '',
      priorityOptions: ['LOW', 'MEDIUM', 'HIGH'],
      datePickerVisible: false,
      menu: false,
      usersDialog: false,
      usersName: [],
      users: [],
      selectedUser: '',
      taskDatas: [],
      currentuserId: this.$store.state.users.staff,
     // isUpdate: false,
    //  buttonToggle: 0,
    }
  },
  methods: {
    // open Dialog
    open() {
      this.dialog = true
      // this.isUpdate = false
      // if (item != null) {
      //   this.getDetails(item)
      // }
    },
    // formClose
    closePopUp() {
      // this.buttonToggle = 0
      this.dialog = false
      this.task = ''
      this.taskDescription = ''
      this.priority = ''
      this.date = ''
      this.selectedStatus = ''
      this.$v.$reset()
    },
    // Assigning-Task-pop-up
    openAddUserDialog() {
      debugger
      this.usersDialog = true
      this.fetchUsers()
    },
async fetchUsers() {
      try {
        this.users = []
        if (this.$store.state.users.adminid > 0)
         {
          this.users.push(this.$store.state.users)
        }
         else {
          // Make the API request using axios
          // 3000?staff=1
          const response = await axios.get 
          (
            process.env.url + '?staff=' + this.currentuserId
          )
          // Check if the response status is OK (status code 200)
          if (response.status === 200) {
            this.users = response.data
            console.log(this.usersName)
            // Extract only the names from the filtered users
            debugger
            // Log the filtered users and extracted names
            console.log('Filtered Users:', this.users)
            // console.log('User Names:', userNames);
          } else {
            console.error(
              'Error fetching users. Response status:',
              response.status
            )
          }
        }
      } 
      catch (error) {
        console.error('Error fetching users:', error)
      }
    },
    closeInnerPopup() {
   this.openAddUserDialog = false
      this.dialog = false
      this.usersDialog = false
      this.selectedUser = ''
     // this.buttonToggle = 0
      this.$v.$reset()
      this.closePopUp()
    },
    // save Task
    async save() {
      debugger
      const Datas = {
        task: this.task,
        taskDescription: this.taskDescription,
        priority: this.priority,
        date: this.date,
        selectedStatus: this.selectedStatus,
        Touserid: this.selectedUser,
        staff: this.currentuserId,
        AssignedBy: this.$store.state.users.name,
      }
      console.log(Datas)
      try {
        // sending request
        const response = await this.$axios.post(process.env.usersDetails, Datas)
        this.taskDatas = response.data
        console.log(response.data)
        this.$emit('EmitSavedDetails', this.taskDatas)
        this.closePopUp()
      } catch (error) {
        console.error('POST request error:', error)
      }
    },
    
  },
}
</script>
<style scoped> 
.parent {
  display: flex;
  justify-content: space-between;
}
</style>
<!-- // getDetails(item) {
  //   this.buttonToggle = 1
  //   this.task = item.task
  //   this.taskDescription = item.taskDescription
  //   this.priority = item.priority
  //   this.date = item.date
  //   this.selectedStatus = item.selectedStatus
  //   this.isUpdate = true
  // }, -->