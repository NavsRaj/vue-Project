<template>
  <div>
 <div>
      <v-alert v-if="dueDate.length != 0"
  border="left"
  color="red"
  type="warning"
  dismissible
>You have got {{ dueDate.length }}  no of task pending after the due date</v-alert>
<v-alert v-if="todayDate.length != 0"
  border="left"
  color="blue"
  type="warning"
  dismissible
>Today is the last due date {{ todayDate.length }}  no of task pending </v-alert>
      <!-- <v-card> -->
      <v-card>
        <v-tabs
          fixed-tabs
          background-color="indigo"
          dark
          v-if="isAdminLoggedIn"
          v-model="tab"
        >
          <v-tab value="All Task" @click="filteredTasks('All Task')">
            All Task
          </v-tab>
          <v-tab value="My Task" @click="filteredTasks('My Task')">
            My Task
          </v-tab>
          <v-tab value="Team Task" @click="filteredTasks('Team Task')">
            Team Task
          </v-tab>
        </v-tabs>
      </v-card>
      <v-btn class="green white--text" @click="openTaskDialog">
        <v-icon> mdi-plus </v-icon> task</v-btn>
    </div>
     <TaskFormDialog 
      ref="taskDialog"
      @EmitSavedDetails="EmitSavedDetail"
    ></TaskFormDialog>
  <div>
    <v-data-table :headers="tableHeaders" :items="yourTaskDataArray">
      <template v-slot:[`item.name`]="{ item }">
      {{ item.name }}
    </template>
      <template v-slot:[`item.selectedStatus`]="{ item }">
       <h5 style="color: red;" v-if="item.selectedStatus==='pending'">{{ item.selectedStatus }}</h5> 
       <h5 style="color: green;" v-else>{{ item.selectedStatus }}</h5> 
      </template>
      <template v-slot:[`item.actions`]="{ item }">
        <v-btn @click="deleteTask(item.id)"
          ><v-icon color="red">mdi-delete</v-icon></v-btn>
          <!-- <v-btn @click="updateTask(item)"
          ><v-icon color="blue">mdi-pencil</v-icon></v-btn> -->
        <v-btn @click="toggleStatus(item)">
          <v-icon :color="item.selectedStatus == 'pending' ? 'grey' : 'green'"
            >mdi-check-circle</v-icon>
        </v-btn>
      </template>
    </v-data-table>
  </div>
</div>
</template>
<script>
import {format} from 'date-fns'
import axios from 'axios'
import TaskFormDialog from '@/components/TaskFormDialog.vue'
export default {
  components: {
    TaskFormDialog,
  },
  layout:'custom',
  data: () => ({
    tab: '',
    tableHeaders: [
      { text: 'ID', value: 'id' },
      { text: 'Task', value: 'task' },
      { text: 'Task Description', value: 'taskDescription' },
      { text: 'Priority', value: 'priority' },
      { text: 'Date', value: 'date' },
      { text: 'Status', value: 'selectedStatus' },
      { text: 'To', value: 'name' },
      { text: 'By', value: 'AssignedBy' },
      { text: 'Team', value: 'staff' },
      { text: 'Actions', value: 'actions', sortable: false, align: 'center' },
    ],
    nameList:[
      {id:1,name:"admin1"},
    {id:2,name:"admin2"},
    {id:3,name:"staff1"},
    {id:4,name:"staff2"},
    {id:5,name:"staff3"},
    {id:6,name:"staff4"},
    {id:7,name:"staff5"},
    {id:8,name:"staff6"}
  ],
    yourTaskDataArray: [],
    TaskDataArray: [],
 dueDate:[],
   todayDate:[],
   dialog: false
  }),
  computed: {
    isAdminLoggedIn() {
      const user = this.$store.state.users
      return user.adminid === 0
    },
    isStaffLoggedIn() {
      const user = this.$store.state.users 
      return  user.adminid > 0 
    },
},
  methods: {
 //  open task form
  openTaskDialog() {
    this.$refs.taskDialog.open()
    },
    // data display based on id & touserid
    async fetchData() {
      this.dueDate=[]
      try {
       let response;
        const user1 = this.$store.state.users
        console.log(user1)
        if (user1.id === 1 || user1.id === 2)
         response = await axios.get(process.env.usersDetails)
        else
          response = await axios.get(
        // 3000?Touserid
            process.env.usersDetails + '?Touserid=' + user1.id
          )
        this.yourTaskDataArray = response.data
        this.TaskDataArray = response.data
        // getting Name
         this.TaskDataArray.forEach((x) => {
          this.nameList.forEach(y=>{
            if(x.Touserid === y.id)
               x.name = y.name
          })
        });
      const date = format(new Date(),'yyyy-MM-dd')
      this.TaskDataArray.forEach(x=>{
        if(x.date < date && x.selectedStatus==='pending'){
          this.dueDate.push(x)
          console.log(x)
          }
          else if( x.date === date && x.selectedStatus ==='pending'){
           this.todayDate.push(x)
          }
      })
            } catch (error) {
        console.error('Error fetching data:', error)
      }
    },
    // delete using id
    async deleteTask(taskId) {
      try {
        await axios.delete(`${process.env.usersDetails}/${taskId}`)
        } catch (error) {
        console.error('Error deleting task:', error)
      }
      this.fetchData()
    },
 // filtering data based on Table  
filteredTasks(val)
 {
      this.tab = val
     let details = []
if (this.tab === 'All Task') 
{
  if (this.isAdminLoggedIn) 
  {
   details = this.TaskDataArray
  }
  else if (this.isStaffLoggedIn) {
         // Display only staff's tasks for staff members
     const userId = this.$store.state.users.id
          details = this.TaskDataArray.filter(
            (task) => task.Touserid === userId
          )
        }
      } 
      else if (this.tab === 'My Task') 
      {
        // Display tasks assigned to the logged-in user
        const userId = this.$store.state.users.id
        details = this.TaskDataArray.filter((task) => task.Touserid === userId)
      } 
      else if (this.tab === 'Team Task') 
      {
        // Display tasks based on staff id
        const staffId = this.$store.state.users.staff
        details = this.TaskDataArray.filter((task) => task.staff === staffId)
      }
      //  assigning data to the table
   this.yourTaskDataArray = details
    },
    // emitting data push into an array 
    EmitSavedDetail(emitData) {
  this.fetchData()
      this.yourTaskDataArray.push(emitData)
    },
  // changing & updating Status  
 async toggleStatus(item) {
      if (item.selectedStatus === 'pending') {
        try {
          item.selectedStatus ="completed"
          await axios.put(`${process.env.usersDetails}/${item.id}`, item)
          item.selectedStatus = 'completed'
        this.fetchData()

        } catch (error) {
          console.error('Error updating status:', error)
        }
      } 
      },

      updateTask(item){
        this.$refs.taskDialog.open(item)
      }
   },
  created() {
    this.fetchData()
    this.filteredTasks()
  },
}
</script>
<style scoped>

</style>
