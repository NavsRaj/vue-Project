<template>
  <div>
    <v-app>
      <header>
        <v-app-bar flat dark class="blue white--text">
          <v-app-bar-title class="headline text-uppercase">
            <h4>
Task Management
            </h4>
          </v-app-bar-title>
          <v-spacer>
</v-spacer>
<v-icon>
  mdi-clock
  </v-icon>
  {{ currentTime }}
<v-spacer>
  </v-spacer>
  <span>
  <v-icon>
    mdi-email
  </v-icon>
  {{users.email}} 
</span>
<v-spacer>  
</v-spacer>
<v-btn color="white black--text" @click="logoutDialog =  true">
  <v-icon>
    mdi-logout
  </v-icon>
  Logout
</v-btn>
        </v-app-bar>
        <v-dialog v-model="logoutDialog" width="400px" persistent>
          <v-card>
<v-card-title class="d-flex justify-center">
 <h5>
  Logout Confirmation?
 </h5> 
</v-card-title>
<v-card-actions class="d-flex justify-center">
<v-btn class="red white--text" @click="logoutDialog = false">
  <v-icon>
    mdi-cancel
    </v-icon>
    cancel
</v-btn>
<v-btn class="green white--text" to ="/">
<v-icon>
  mdi-logout
</v-icon>
Log-out
</v-btn>
</v-card-actions>
          </v-card>
        </v-dialog>
</header>
        <v-main>
  <Nuxt />
</v-main> 
<v-footer app height=30 class="pa-5" color="blue white--text">
    <v-spacer></v-spacer>
    <v-row>
      <div> 
      &copy; <span>STS-759 NAVEENRAJ.C</span>
    </div>
    </v-row>
   </v-footer> 
    </v-app>
  </div>
  </template>
  <script>
export default{
    data(){
      return{
        logoutDialog : false,
        currentTime:'',
        users: this.$store.state.users,
        notifyDialog:false,
        dueDate:[]
      }
     },
     methods:{
      updateCurrentTime() {
      const now = new Date()
      const hours = now.getHours().toString().padStart(2,'0')
      const minutes = now.getMinutes().toString().padStart(2, '0')
      const seconds = now.getSeconds().toString().padStart(2, '0')
      this.currentTime = `${hours}:${minutes}:${seconds}`
    },
    closeNotify() {
        
        this.notifyDialog = false
      },
     open()
     {
      this.notifyDialog =true
       }
     },
     created(){
      this.updateCurrentTime()
    setInterval(this.updateCurrentTime, 1000)
     },
    }
</script>
<style scoped>
/* .v-application--wrap{
  min-height: 0vh;
} */
</style>