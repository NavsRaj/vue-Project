<template>
  <div>
    <v-app>
      <header>
<v-app-bar  flat dark class="blue  white--text">
        <v-app-bar-title class="headline text-uppercase">
          <h4>
            Task Management
          </h4>
        </v-app-bar-title>
        <v-spacer></v-spacer>
        <span>
          <v-icon>
            mdi-clock
          </v-icon>
           {{ currentTime }}
        </span>
      </v-app-bar>
    </header>
    <v-main>
      <Nuxt />
    </v-main>
    <v-footer app height=30 class="pa-5 blue white--text fw-bold ">
    <v-spacer></v-spacer>
    <v-row>
      <div>
      &copy; <span>STS-759 NAVEENRAJ.C </span>
    </div>
    </v-row>
   </v-footer>
    </v-app>
  </div>
  </template>
  <script>
  export default{
    name: 'DefaultLayout',

data() {
    return {
      currentTime: '',
    }
  },
  methods: {
    updateCurrentTime() {
      const now = new Date()
      const hours = now.getHours().toString().padStart(2,'0')
      const minutes = now.getMinutes().toString().padStart(2, '0')
      const seconds = now.getSeconds().toString().padStart(2, '0')
      this.currentTime = `${hours}:${minutes}:${seconds}`
    },
  },
  created(){
    this.updateCurrentTime()
    setInterval(this.updateCurrentTime, 1000)
  }
  }
</script>
<style>
</style>