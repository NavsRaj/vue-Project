export const state = () => ({
  users:{},
   isUserAuthenticated:false,
})
// mutations for value set
     export const mutations = {
 setUsers(state,users){
 state.users = users 
 localStorage.setUsers('users',users)
  }
 }
