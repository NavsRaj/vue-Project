export default function(context)
{
// context.$post(
//   "process.env.url",
//   {
//     email:"admin@gmail.com",
//     password:"Admin@11"
//   }
// )
// .then(

// )
console.log("i am middleware");
}