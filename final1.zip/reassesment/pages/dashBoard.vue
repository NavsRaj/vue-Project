<template>
  <div>
<DashBoardComponent >
  </DashBoardComponent>
  </div>
  </template>
  <script>
import DashBoardComponent from '~/components/dashBoardComponent.vue';

  export default{
    // middleware: 'auth',
    name: 'dashBoard',
    layout: 'custom',
    components: { DashBoardComponent },
   
}
</script>
<style scoped>
.v-application--wrap {
    flex: 1 1 auto;
    backface-visibility: hidden;
    display: flex;
    flex-direction: column;
     min-height: auto;
    max-width: 100%;
    position: relative;
}
</style>