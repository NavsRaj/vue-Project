<template>
  <div>
    <loginComponent>
      </loginComponent>
  </div>
  </template>
  <script>
  import loginComponent from '@/components/loginComponent.vue'
  export default{
 
    components:{
      loginComponent
    }
  }
</script>
<style scoped>
</style>